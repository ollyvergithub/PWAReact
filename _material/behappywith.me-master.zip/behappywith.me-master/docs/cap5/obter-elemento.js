// Este código não funciona, exceto se estiver vinculado a um HTML e uma importação do JQuery

// JQuery
$( "#id_do_input" ).val();

// JavaScript
document.getElementById('id_do_input').value;